const express = require('express');
const app = express();
const PORT = 3000;

const fs=require('fs/promises')
const FILE_PATH='./user.json'
app.use(express.urlencoded({ extended: true }));
const m1=(req,res,next)=>{
    const age=req.query.age;
    if(!age)
    {
         res.status(404).json({ msg: "No such user" });
    }
    else{
        if(age<18){
            res.status(404).json({ msg: "user not authorised" }); 
        }
        else{
            next()
        }
    }
}
const readUsers=async()=>{
    try {
        const data = await fs.readFile(FILE_PATH, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        return []
    }
}
const writeUsers = async (users) => {
    await fs.writeFile(FILE_PATH, JSON.stringify(users, null, 2));
};
app.use(express.json());//application level 

app.get('/users', async(req, res) => {
  const users=await readFile()
  res.send(users)
});

app.get('/users/:id', async(req, res) => {
    const uid = Number(req.params.id);
    const users = await readUsers();
    const index = users.findIndex(ind => ind.id===uid);

    if (index === -1) {
        return res.status(404).json({ msg: "No such user" });
    }
    res.status(200).json({ msg: "User found", user: users[index] });
});

app.post('/createuser',m1, async(req, res) => { //router level middleware 
    const { name, email } = req.body;

    if (!name || !email) {
        return res.status(400).json({ msg: "Name and email are required" });
    }

    const users = await readUsers();
    const newUser = { id: Date.now(), name, email };

    users.push(newUser);
    await writeUsers(users);
    res.status(201).json({ msg: "User added", user: newUser });
});

app.use(express.urlencoded({ extended: true })); // Middleware for form data

app.patch('/edituser/:id', async(req, res) => {
    console.log(req.body); 

    const uid = Number(req.params.id);
    const { name, email } = req.body;
    const users=await readUsers();
    const index = users.findIndex(ind => ind.id === uid);
    if (index === -1) {
        return res.status(404).json({ msg: "No such user" });
    }

    users[index].name = name;
    users[index].email = email;
    await writeUsers(users)
    console.log(users[index]); 
    res.status(200).json({ msg: "User updated", user: users[index] });
});

app.delete('/deleteuser/:id',async (req, res) => {
    const uid = Number(req.params.id);
    const users=await readUsers();
    const index = users.findIndex(ind => ind.id === uid);

    if (index === -1) {
        return res.status(404).json({ msg: "No such user" });
    }

    const deletedUser = users.splice(index, 1)[0];
    await writeUsers(users)
    res.status(200).json({ msg: "User deleted", user: deletedUser });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
